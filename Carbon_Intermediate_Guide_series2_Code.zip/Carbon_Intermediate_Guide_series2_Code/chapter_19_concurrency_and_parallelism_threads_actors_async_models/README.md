# Concurrency and Parallelism (Threads, Actors, Async Models)

This folder contains sample code illustrating core concepts for this chapter.

**Files included**
- `examples/concurrency.carbon`

> These are illustrative, Carbon-like examples suitable for learning and quick experimentation.
