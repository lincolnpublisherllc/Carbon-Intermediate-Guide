# Functions, Modules, and Code Organization at Scale

This folder contains sample code illustrating core concepts for this chapter.

**Files included**
- `examples/io_example.carbon`

> These are illustrative, Carbon-like examples suitable for learning and quick experimentation.
