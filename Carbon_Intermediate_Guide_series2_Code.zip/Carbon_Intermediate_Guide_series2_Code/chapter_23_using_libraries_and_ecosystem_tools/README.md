# Using Libraries and Ecosystem Tools

This folder contains sample code illustrating core concepts for this chapter.

**Files included**
- `main.carbon`

> These are illustrative, Carbon-like examples suitable for learning and quick experimentation.
