# Carbon Intermediate Guide — Series 2 (Code Pack)

This archive contains **chapter-by-chapter sample code**, generated from the uploaded manuscript’s chapter list
(extracted from DOCX). Each chapter folder includes
a small set of example files in a Carbon-like teaching syntax.

> **Note:** These examples are designed as learning scaffolds and may use simplified/illustrative APIs.

## How this is organized
- One folder per chapter: `chapter_##_<slug>/`
- Inside each chapter:
  - `README.md` — what’s in this chapter’s code
  - `main.carbon` — a small runnable-style entry example
  - `examples/` — tiny, focused snippets (where applicable)

Generated on: 2025-09-15T02:35:02.947813Z
