# Data Structures in Depth (Sets, Maps, Trees, Tuples)

This folder contains sample code illustrating core concepts for this chapter.

**Files included**
- `examples/data_structures.carbon`

> These are illustrative, Carbon-like examples suitable for learning and quick experimentation.
